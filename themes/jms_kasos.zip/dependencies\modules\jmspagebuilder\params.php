<?php
/**
* 2007-2017 PrestaShop
*
* Jms Page Builder
*
*  @author    Joommasters <joommasters@gmail.com>
*  @copyright 2007-2017 Joommasters
*  @license   license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*  @Website: http://www.joommasters.com
*/

define('_JPB_THEMESKINS_', "color1,color2,color3,color4");
define('_JPB_PRODUCTHOVERS_', "image_blur:Image Blur,image_swap:Image Swap");
define('_JPB_PRODUCTBOXS_', '');
